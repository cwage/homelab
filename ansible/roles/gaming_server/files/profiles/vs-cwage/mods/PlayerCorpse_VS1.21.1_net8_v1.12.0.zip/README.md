# PlayerCorpse

### Links: [ModDB](https://mods.vintagestory.at/playercorpse), [Forum](https://www.vintagestory.at/forums/topic/3784-player-corpse)
